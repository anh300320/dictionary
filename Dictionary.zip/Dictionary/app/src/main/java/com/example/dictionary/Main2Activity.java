package com.example.dictionary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.SearchView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

import Objects.Word;
import Retrofit.RetrofitBuilder;
import Retrofit.RetrofitService;
import bottom.fragments.BookmarkFragment;
import bottom.fragments.DictionaryFragment;
import bottom.fragments.UserFragment;
import bottom.fragments.VocabularyFragment;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Main2Activity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    RetrofitService retrofitService = RetrofitBuilder.build("https://nhqt-dict.herokuapp.com/api/");

    FrameLayout frameLayout;
    DictionaryFragment dictionaryFragment = new DictionaryFragment();
    UserFragment userFragment = new UserFragment();

    List<Word> listWords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        SharedPreferences sharedPreferences = getBaseContext().getSharedPreferences("com.dictionary.USER_ACCESS", Context.MODE_PRIVATE);
        String accessToken = sharedPreferences.getString("access_token", "null");
        Log.d("hehehe", accessToken);

        findViewById();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new DictionaryFragment()).commit();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Fragment selectedFragment = null;

                switch(menuItem.getItemId()){
                    case R.id.navigation_dict:
                        selectedFragment = dictionaryFragment;
                        break;
                    case R.id.navigation_vocab:
                        selectedFragment = new VocabularyFragment();
                        break;
                    case R.id.navigation_bookmark:
                        selectedFragment = new BookmarkFragment();
                        break;
                    case R.id.navigation_user:
                        selectedFragment = userFragment;
                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
                return true;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.home_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.home_menu_search);
        final SearchView searchView =(SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                if(!dictionaryFragment.isVisible()) bottomNavigationView.setSelectedItemId(R.id.navigation_dict);
                Call<List<Word>> search = retrofitService.search(query);
                search.enqueue(new Callback<List<Word>>() {
                    @Override
                    public void onResponse(Call<List<Word>> call, Response<List<Word>> response) {
                        listWords = response.body();
                        dictionaryFragment.searchingWord(listWords);
                        Log.d("hehehe", "onResponse: search");
                    }

                    @Override
                    public void onFailure(Call<List<Word>> call, Throwable t) {
                        Log.d("hehehe", "onFailure: searching...");
                    }
                });
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(!dictionaryFragment.isVisible()) bottomNavigationView.setSelectedItemId(R.id.navigation_dict);
                Call<List<Word>> search = retrofitService.search(newText);
                search.enqueue(new Callback<List<Word>>() {
                    @Override
                    public void onResponse(Call<List<Word>> call, Response<List<Word>> response) {
                        listWords = response.body();
                        dictionaryFragment.searchingWord(listWords);
                        Log.d("hehehe", "onResponse: search");
                    }

                    @Override
                    public void onFailure(Call<List<Word>> call, Throwable t) {
                        Log.d("hehehe", "onFailure: searching...");
                    }
                });
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    public void findViewById(){
        bottomNavigationView = findViewById(R.id.navigation_view);
        frameLayout = findViewById(R.id.fragment_container);
    }
}
