package myinterfaces;

import android.view.View;

public interface ItemClickListener{

    public void onClick(View view, int position);
}
